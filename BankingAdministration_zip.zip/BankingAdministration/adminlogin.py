#!C:\Users\HP\AppData\Local\Programs\Python\Python39\python.exe
print("content-type:text/HTML\n\r\n\r")


import mysql.connector
import cgi
form = cgi.FieldStorage()
t1 = form.getvalue("username")
t2 = form.getvalue("password")

mydb = mysql.connector.connect(host="localhost",user="root",password="",database="BankingDatabase")
cur = mydb.cursor()
sqlquery = "select uName from CustDataTab where uName = '"+t1+"' and password= '"+t2+"' "
cur.execute(sqlquery)

ch = 0
for uName in cur:
    print("<tr><td>",uName,"</td></tr>")
    ch=1

cur.close()
mydb.close()

if ch == 1:
    redirecturl = "adminmain.html"
    print('<meta http-equiv="refresh" content="0; url='+str(redirecturl)+'"/>')
else:
    redirecturl = "adminlogin.html"
    print('<meta http-equiv="refresh" content="0; url='+str(redirecturl)+'"/>')
