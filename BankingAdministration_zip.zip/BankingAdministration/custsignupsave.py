#!C:\Users\HP\AppData\Local\Programs\Python\Python39\python.exe
print("content-type:text/HTML\n\r\n\r")


import mysql.connector
import cgi
form = cgi.FieldStorage()

t1 = form.getvalue("username")
t2 = form.getvalue("password")
t3 = form.getvalue("retypepassword")
t4 = form.getvalue("custname")
t5 = form.getvalue("custaddress")
t6 = form.getvalue("mobnum")
t7 = form.getvalue("email")


mydb = mysql.connector.connect(host="localhost",user="root",password="",database="BankingDatabase")
cur = mydb.cursor()
add_values = ("insert into CustDataTable values(%s,%s,%s,%s,%s,%s)")
data_values = (t1,t2,t4,t5,t6,t7)
cur.execute(add_values,data_values)

mydb.commit()
cur.close()
mydb.close()

redirecturl = "mainpage.html"
print('<meta http-equiv="refresh" content="0; url='+str(redirecturl)+'"/>')