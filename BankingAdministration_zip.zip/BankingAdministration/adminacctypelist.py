#!C:\Users\HP\AppData\Local\Programs\Python\Python39\python.exe
print("content-type:text/HTML\n\r\n\r")

import mysql.connector

mydb = mysql.connector.connect(host="localhost",user="root",password="",database="BankingDatabase")
cur = mydb.cursor()
sqlquery = "select AcctypeName,details from AccTypeTab order by AccTypeName"
cur.execute(sqlquery)

print("<a href='adminmain.html'> Admin Main </a>")
print("<br><br>")
print("<table border=1 width='40%' align=center ")
print("<tr><td>Acc Type Name</td><td>Details</td></tr>")

for (AccTypeName,details) in cur:
    print("<tr><td>",AccTypeName,"</td><td>",details,"</td></tr>")

print("</table>")

cur.close()
mydb.close()