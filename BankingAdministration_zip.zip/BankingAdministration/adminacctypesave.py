#!C:\Users\HP\AppData\Local\Programs\Python\Python39\python.exe
print("content-type:text/HTML\n\r\n\r")


import mysql.connector
import cgi
form = cgi.FieldStorage()
t1 = form.getvalue("acctype")
t2 = form.getvalue("accdetails")

mydb = mysql.connector.connect(host="localhost",user="root",password="",database="BankingDatabase")
cur = mydb.cursor()
add_values = ("insert into AccTypeTab values(%s,%s)")
data_values = (t1,t2)
cur.execute(add_values,data_values)

mydb.commit()
cur.close()
mydb.close()

redirecturl = "adminmain.html"
print('<meta http-equiv="refresh" content="0; url='+str(redirecturl)+'"/>')